
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as l,r as n,h as a,E as s,$ as e,bw as u,bt as t,ay as i,az as c,S as d}from"./index.84c9bfd8.js";import o from"./index.92b6d9e7.js";const r="_example-icon_jktcf_1",f="_test1_jktcf_5",_="_a_jktcf_8",m="_test2_jktcf_14",p=l({name:"JsxExample",render(){const l=n(["sidebar-jsx","sidebar-element"]).value.map((l=>a(s,{class:r},{default:()=>[a(d,{name:l},null)]})));let p=n(0);const v=a("p",null,[e("这也是"),a("i",null,[e("一段")]),a("b",null,[e("HTML")]),e("代码")]);return a("div",null,[a(u,{title:"JSX",content:"请查看本页面源码，更多 JSX 介绍请访问官网文档。"},null),a(t,null,{default:()=>[a("p",null,[e("这是两个 Svg Icon 图标")]),l,a(i,null,null),a("div",{class:f},[a("div",{class:_},null)]),a("div",{class:m},[a("div",{class:_},null)]),a(i,null,null),a(c,{onClick:()=>function(l=1){p.value+=l}(10)},{default:()=>[e("点我："),p.value]}),a("div",{innerHTML:"<p>这是<i>一段</i><b>HTML</b>代码</p>"},null),v,a(i,null,null),a(o,null,null)]})])}});export{p as default};

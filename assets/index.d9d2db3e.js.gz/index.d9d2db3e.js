
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as e,d as a,y as s,M as i,b as n,e as t,w as l,i as d,f as o,h as m,m as c,D as r,H as u,Q as f,T as v,n as b,G as p,U as h,E as g}from"./index.cc47405f.js";import j from"./index.6936ddcf.js";import{u as k}from"./index.f71f9929.js";import"./logo.d9b7b1d5.js";const M={key:0,class:"main-sidebar-container"},x={class:"nav"},y=["title","onClick"],_=a({name:"MainSidebar"}),w=e(Object.assign(_,{setup(e){const a=s(),_=i();return(e,s)=>{const i=h,w=g;return n(),t(v,{name:"main-sidebar"},{default:l((()=>["side"===d(a).menu.menuMode||"mobile"===d(a).mode&&"single"!==d(a).menu.menuMode?(n(),o("div",M,[m(j,{"show-title":!1,class:"sidebar-logo"}),c(" 侧边栏模式（含主导航） "),r("div",x,[(n(!0),o(u,null,f(d(_).allMenus,((e,a)=>(n(),o(u,null,[e.children&&0!==e.children.length?(n(),o("div",{key:a,class:b({item:!0,active:a===d(_).actived}),title:e.meta.title,onClick:e=>d(k)().switchTo(a)},[m(w,null,{default:l((()=>[e.meta.icon?(n(),t(i,{key:0,name:e.meta.icon},null,8,["name"])):c("v-if",!0)])),_:2},1024),r("span",null,p(e.meta.title),1)],10,y)):c("v-if",!0)],64)))),256))])])):c("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-ebc95e63"]]);export{w as default};

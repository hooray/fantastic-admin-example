
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as e,E as a,f as t,h as l,w as d,bl as s,bL as f,b as i,$ as u,bO as n,R as _}from"./index.1763518e.js";import{E as r}from"./el-link.f9b2948e.js";import p from"./alert.f1ae7d5c.js";import"./el-alert.81f303c4.js";const o=u("默认链接"),c=u("主要链接"),m=u("成功链接"),y=u("警告链接"),b=u("危险链接"),g=u("信息链接"),v=u("默认链接"),h=u("主要链接"),j=u("成功链接"),w=u("警告链接"),k=u("危险链接"),x=u("信息链接"),E=u("无下划线"),I=u("有下划线"),L=u(" 编辑 "),O=u(" 查看 "),R={__name:"link",setup:e=>(e,s)=>{const u=n,R=r,$=f,q=_,z=a;return i(),t("div",null,[l(p),l(u,{title:"文字链接"}),l($,{title:"基础用法",class:"demo"},{default:d((()=>[l(R,{href:"https://element.eleme.io",target:"_blank"},{default:d((()=>[o])),_:1}),l(R,{type:"primary"},{default:d((()=>[c])),_:1}),l(R,{type:"success"},{default:d((()=>[m])),_:1}),l(R,{type:"warning"},{default:d((()=>[y])),_:1}),l(R,{type:"danger"},{default:d((()=>[b])),_:1}),l(R,{type:"info"},{default:d((()=>[g])),_:1})])),_:1}),l($,{title:"禁用状态",class:"demo"},{default:d((()=>[l(R,{disabled:""},{default:d((()=>[v])),_:1}),l(R,{type:"primary",disabled:""},{default:d((()=>[h])),_:1}),l(R,{type:"success",disabled:""},{default:d((()=>[j])),_:1}),l(R,{type:"warning",disabled:""},{default:d((()=>[w])),_:1}),l(R,{type:"danger",disabled:""},{default:d((()=>[k])),_:1}),l(R,{type:"info",disabled:""},{default:d((()=>[x])),_:1})])),_:1}),l($,{title:"下划线",class:"demo"},{default:d((()=>[l(R,{underline:!1},{default:d((()=>[E])),_:1}),l(R,null,{default:d((()=>[I])),_:1})])),_:1}),l($,{title:"图标",class:"demo"},{default:d((()=>[l(R,null,{default:d((()=>[l(z,{class:"el-icon--left"},{default:d((()=>[l(q,{name:"ep:edit"})])),_:1}),L])),_:1}),l(R,null,{default:d((()=>[O,l(z,{class:"el-icon--right"},{default:d((()=>[l(q,{name:"ep:view"})])),_:1})])),_:1})])),_:1})])}};"function"==typeof s&&s(R);var $=e(R,[["__scopeId","data-v-63ee6c7f"]]);export{$ as default};

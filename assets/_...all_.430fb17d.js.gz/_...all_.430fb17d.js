
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,r as n,bt as s,o as t,az as e,f as c,h as o,D as l,w as u,bu as r,aE as d,b as v,R as i,G as f,I as p,J as m,U as w}from"./index.8b097f1d.js";const I=a=>(p("data-v-71cc7d2f"),a=a(),m(),a),_={class:"notfound"},b={class:"content"},h=I((()=>l("h1",null,"404",-1))),y=I((()=>l("div",{class:"desc"},"抱歉，你访问的页面不存在",-1))),x={__name:"[...all]",setup(a){const r=d(),p=n({inter:null,countdown:5});function m(){r.push("/")}return s((()=>{clearInterval(p.value.inter)})),t((()=>{p.value.inter=setInterval((()=>{p.value.countdown--,0==p.value.countdown&&(clearInterval(p.value.inter),m())}),1e3)})),(a,n)=>{const s=w,t=e;return v(),c("div",_,[o(s,{name:"404",class:"icon"}),l("div",b,[h,y,o(t,{type:"primary",onClick:m},{default:u((()=>[i(f(p.value.countdown)+" 秒后，返回首页",1)])),_:1})])])}}};"function"==typeof r&&r(x);const j=a(x,[["__scopeId","data-v-71cc7d2f"]]);export{j as default};


/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as e,E as a,az as t,f as s,h as l,w as n,bu as d,bv as o,b as u,R as r,by as p,U as c}from"./index.edceb537.js";import i from"./alert.6c5246b2.js";import"./el-alert.9066d762.js";import"./el-link.7532a844.js";const m=r(" 搜索 "),f={__name:"icon",setup:e=>(e,d)=>{const r=p,f=c,_=a,b=t,j=o;return u(),s("div",null,[l(i),l(r,{title:"图标"}),l(j,{class:"demo"},{default:n((()=>[l(_,null,{default:n((()=>[l(f,{name:"ep:edit"})])),_:1}),l(_,null,{default:n((()=>[l(f,{name:"ep:share"})])),_:1}),l(_,null,{default:n((()=>[l(f,{name:"ep:delete"})])),_:1}),l(b,{type:"primary"},{icon:n((()=>[l(_,null,{default:n((()=>[l(f,{name:"ep:search"})])),_:1})])),default:n((()=>[m])),_:1})])),_:1})])}};"function"==typeof d&&d(f);const _=e(f,[["__scopeId","data-v-5c7b21ce"]]);export{_ as default};

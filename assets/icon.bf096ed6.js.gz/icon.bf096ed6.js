
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as e,E as a,aw as l,f as t,h as s,w as n,bl as d,bL as r,b as o,$ as u,bO as c,R as f}from"./index.773474dc.js";import p from"./alert.c3eb6172.js";import"./el-alert.5c137829.js";import"./el-link.1df0c4c7.js";const i=u(" 搜索 "),m={__name:"icon",setup:e=>(e,d)=>{const u=c,m=f,_=a,b=l,j=r;return o(),t("div",null,[s(p),s(u,{title:"图标"}),s(j,{class:"demo"},{default:n((()=>[s(_,null,{default:n((()=>[s(m,{name:"ep:edit"})])),_:1}),s(_,null,{default:n((()=>[s(m,{name:"ep:share"})])),_:1}),s(_,null,{default:n((()=>[s(m,{name:"ep:delete"})])),_:1}),s(b,{type:"primary"},{icon:n((()=>[s(_,null,{default:n((()=>[s(m,{name:"ep:search"})])),_:1})])),default:n((()=>[i])),_:1})])),_:1})])}};"function"==typeof d&&d(m);var _=e(m,[["__scopeId","data-v-5dc6bf25"]]);export{_ as default};

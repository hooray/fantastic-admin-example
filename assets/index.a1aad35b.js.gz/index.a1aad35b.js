
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,d as e,y as s,M as i,b as n,e as t,w as d,i as c,f as o,D as l,h as m,m as r,H as f,Q as u,T as v,n as p,G as h,U as j,E as k}from"./index.cc47405f.js";import x from"./index.6936ddcf.js";import{T as y}from"./index.a70595c1.js";import{u as b}from"./index.f71f9929.js";import"./logo.d9b7b1d5.js";import"./index.da6a5ccc.js";import"./eventBus.193de119.js";const _={key:0},g={class:"header-container"},M={class:"main"},T={class:"nav"},w=["onClick"],C={key:0},H=e({name:"Header"}),B=a(Object.assign(H,{setup(a){const e=s(),H=i();return(a,s)=>{const i=j,B=k;return n(),t(v,{name:"header"},{default:d((()=>["pc"===c(e).mode&&"head"===c(e).menu.menuMode?(n(),o("header",_,[l("div",g,[l("div",M,[m(x),r(" 顶部模式 "),l("div",T,[(n(!0),o(f,null,u(c(H).allMenus,((a,e)=>(n(),o(f,null,[a.children&&0!==a.children.length?(n(),o("div",{key:e,class:p(["item",{active:e==c(H).actived}]),onClick:a=>c(b)().switchTo(e)},[m(B,null,{default:d((()=>[a.meta.icon?(n(),t(i,{key:0,name:a.meta.icon},null,8,["name"])):r("v-if",!0)])),_:2},1024),a.meta.title?(n(),o("span",C,h(a.meta.title),1)):r("v-if",!0)],10,w)):r("v-if",!0)],64)))),256))])]),m(y)])])):r("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-e3de8320"]]);export{B as default};


/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,r as n,bk as s,o as e,aw as t,f as l,h as o,B as c,w as u,bl as r,N as d,O as v,F as i,b as f,$ as p,L as w,R as m}from"./index.6dffb2c9.js";const _=a=>(d("data-v-1ae77076"),a=a(),v(),a),b={class:"notfound"},I={class:"content"},h=_((()=>c("h1",null,"404",-1))),y=_((()=>c("div",{class:"desc"},"抱歉，你访问的页面不存在",-1))),k={__name:"[...all]",setup(a){const r=i(),d=n({inter:null,countdown:5});function v(){r.push("/")}return s((()=>{clearInterval(d.value.inter)})),e((()=>{d.value.inter=setInterval((()=>{d.value.countdown--,0==d.value.countdown&&(clearInterval(d.value.inter),v())}),1e3)})),(a,n)=>{const s=m,e=t;return f(),l("div",b,[o(s,{name:"404",class:"icon"}),c("div",I,[h,y,o(e,{type:"primary",onClick:v},{default:u((()=>[p(w(d.value.countdown)+" 秒后，返回首页",1)])),_:1})])])}}};"function"==typeof r&&r(k);var x=a(k,[["__scopeId","data-v-1ae77076"]]);export{x as default};

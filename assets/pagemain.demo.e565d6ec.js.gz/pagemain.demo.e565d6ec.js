
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as t,aw as a,ci as l,bM as e,f as s,h as n,w as i,bl as d,bL as u,b as f,B as o,$ as r,bO as m}from"./index.d2f116bb.js";import{_ as p}from"./logo.96f1da49.js";const _={},c=r(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),g=r(" 这里放页面内容 "),x={style:{display:"flex","align-item":"center","justify-content":"space-between"}},b=r(" 通过 slot 设置标题 "),y=r("还可以放置自定义按钮"),h=r(" 这里放页面内容 "),v=r(" 还可以结合 ElRow 使用 "),w=r(" 这里放页面内容 "),j=r(" 这里放页面内容 "),M=o("h1",null,"Fantastic-admin",-1),P=o("img",{src:p},null,-1),z=o("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);"function"==typeof d&&d(_);var B=t(_,[["render",function(t,d){const r=m,p=u,_=a,B=l,E=e;return f(),s("div",null,[n(r,{title:"内容块",content:"PageMain"}),n(p,null,{default:i((()=>[c])),_:1}),n(p,{title:"你可以设置一个自定义的标题"},{default:i((()=>[g])),_:1}),n(p,null,{title:i((()=>[o("div",x,[b,n(_,{size:"small"},{default:i((()=>[y])),_:1})])])),default:i((()=>[h])),_:1}),n(E,{gutter:20,style:{margin:"-10px 10px"}},{default:i((()=>[n(B,{md:8},{default:i((()=>[n(p,{style:{margin:"10px 0"}},{default:i((()=>[v])),_:1})])),_:1}),n(B,{md:8},{default:i((()=>[n(p,{style:{margin:"10px 0"}},{default:i((()=>[w])),_:1})])),_:1}),n(B,{md:8},{default:i((()=>[n(p,{style:{margin:"10px 0"}},{default:i((()=>[j])),_:1})])),_:1})])),_:1}),n(p,{title:"带展开功能",collaspe:"",height:"200px"},{default:i((()=>[M,P,z])),_:1})])}]]);export{B as default};

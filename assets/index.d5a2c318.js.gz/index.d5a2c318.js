
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,d as e,z as s,B as i,Q as n,b as t,e as l,w as d,i as o,f as m,h as c,m as r,H as u,N as b,R as v,T as f,n as p,M as h,S as M,E as g}from"./index.84c9bfd8.js";import k from"./index.36d6e1db.js";import"./logo.d9b7b1d5.js";const j={key:0,class:"main-sidebar-container"},_={class:"nav"},w=["title","onClick"],x=e({name:"MainSidebar"}),y=a(Object.assign(x,{setup(a){const e=s(),x=i(),y=n("switchMenu");return(a,s)=>{const i=M,n=g;return t(),l(f,{name:"main-sidebar"},{default:d((()=>["side"===o(e).menu.menuMode||"mobile"===o(e).mode&&"single"!==o(e).menu.menuMode?(t(),m("div",j,[c(k,{"show-title":!1,class:"sidebar-logo"}),r(" 侧边栏模式（含主导航） "),u("div",_,[(t(!0),m(b,null,v(o(x).allMenus,((a,e)=>(t(),m(b,null,[a.children&&0!==a.children.length?(t(),m("div",{key:e,class:p({item:!0,active:e===o(x).actived}),title:a.meta.title,onClick:a=>o(y)(e)},[c(n,null,{default:d((()=>[a.meta.icon?(t(),l(i,{key:0,name:a.meta.icon},null,8,["name"])):r("v-if",!0)])),_:2},1024),u("span",null,h(a.meta.title),1)],10,w)):r("v-if",!0)],64)))),256))])])):r("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-a23a086e"]]);export{y as default};

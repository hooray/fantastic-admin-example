
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,E as e,aw as l,f as t,h as s,w as n,bl as d,bL as r,b as f,$ as o,bO as u,R as p}from"./index.d2f116bb.js";import i from"./alert.df63805e.js";import"./el-alert.ae4a5054.js";import"./el-link.b35aa2e5.js";const m=o(" 搜索 "),_={__name:"icon",setup:a=>(a,d)=>{const o=u,_=p,c=e,b=l,j=r;return f(),t("div",null,[s(i),s(o,{title:"图标"}),s(j,{class:"demo"},{default:n((()=>[s(c,null,{default:n((()=>[s(_,{name:"ep:edit"})])),_:1}),s(c,null,{default:n((()=>[s(_,{name:"ep:share"})])),_:1}),s(c,null,{default:n((()=>[s(_,{name:"ep:delete"})])),_:1}),s(b,{type:"primary"},{icon:n((()=>[s(c,null,{default:n((()=>[s(_,{name:"ep:search"})])),_:1})])),default:n((()=>[m])),_:1})])),_:1})])}};"function"==typeof d&&d(_);var c=a(_,[["__scopeId","data-v-5dc6bf25"]]);export{c as default};

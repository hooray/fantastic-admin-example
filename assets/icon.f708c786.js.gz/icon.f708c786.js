
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as e,E as a,aw as l,f as t,h as s,w as d,bl as n,bL as r,b as o,$ as u,bO as f,R as p}from"./index.dbeb19dd.js";import c from"./alert.b2b5cc8c.js";import"./el-alert.83855865.js";import"./el-link.c28e9f5d.js";const i=u(" 搜索 "),m={__name:"icon",setup:e=>(e,n)=>{const u=f,m=p,_=a,b=l,j=r;return o(),t("div",null,[s(c),s(u,{title:"图标"}),s(j,{class:"demo"},{default:d((()=>[s(_,null,{default:d((()=>[s(m,{name:"ep:edit"})])),_:1}),s(_,null,{default:d((()=>[s(m,{name:"ep:share"})])),_:1}),s(_,null,{default:d((()=>[s(m,{name:"ep:delete"})])),_:1}),s(b,{type:"primary"},{icon:d((()=>[s(_,null,{default:d((()=>[s(m,{name:"ep:search"})])),_:1})])),default:d((()=>[i])),_:1})])),_:1})])}};"function"==typeof n&&n(m);var _=e(m,[["__scopeId","data-v-5dc6bf25"]]);export{_ as default};

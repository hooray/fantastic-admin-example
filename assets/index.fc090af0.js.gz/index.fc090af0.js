
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,d as e,x as s,z as n,E as i,e as t,w as d,T as l,P as c,b as m,i as o,f as r,B as u,h as v,m as f,M as h,Q as p,n as k,L as j,R as x}from"./index.773474dc.js";import y from"./index.9b9c3a33.js";import M from"./index.9c9a9785.js";import"./logo.96f1da49.js";const _={key:0},b={class:"header-container"},g={class:"main"},w={class:"nav"},C=["onClick"],z={key:0},B=e({name:"Header"});var E=a(Object.assign(B,{setup(a){const e=s(),B=n(),E=c("switchMenu");return(a,s)=>{const n=x,c=i;return m(),t(l,{name:"header"},{default:d((()=>["pc"===o(e).mode&&"head"===o(e).menu.menuMode?(m(),r("header",_,[u("div",b,[u("div",g,[v(y),f(" 顶部模式 "),u("div",w,[(m(!0),r(h,null,p(o(B).allMenus,((a,e)=>(m(),r(h,null,[a.children&&0!==a.children.length?(m(),r("div",{key:e,class:k(["item",{active:e==o(B).actived}]),onClick:a=>o(E)(e)},[v(c,null,{default:d((()=>[a.meta.icon?(m(),t(n,{key:0,name:a.meta.icon},null,8,["name"])):f("v-if",!0)])),_:2},1024),a.meta.title?(m(),r("span",z,j(a.meta.title),1)):f("v-if",!0)],10,C)):f("v-if",!0)],64)))),256))])]),v(M)])])):f("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-339849a1"]]);export{E as default};


/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,d as e,x as s,z as n,E as i,e as t,w as d,T as l,Q as c,b as m,i as o,f as r,C as u,h as v,m as f,N as h,R as p,n as k,M as j,S as x}from"./index.7e6c6c91.js";import b from"./index.b0d67396.js";import y from"./index.b05dc0ae.js";import"./logo.96f1da49.js";const M={key:0},_={class:"header-container"},g={class:"main"},C={class:"nav"},w=["onClick"],z={key:0},E=e({name:"Header"});var H=a(Object.assign(E,{setup(a){const e=s(),E=n(),H=c("switchMenu");return(a,s)=>{const n=x,c=i;return m(),t(l,{name:"header"},{default:d((()=>["pc"===o(e).mode&&"head"===o(e).menu.menuMode?(m(),r("header",M,[u("div",_,[u("div",g,[v(b),f(" 顶部模式 "),u("div",C,[(m(!0),r(h,null,p(o(E).allMenus,((a,e)=>(m(),r(h,null,[a.children&&0!==a.children.length?(m(),r("div",{key:e,class:k(["item",{active:e==o(E).actived}]),onClick:a=>o(H)(e)},[v(c,null,{default:d((()=>[a.meta.icon?(m(),t(n,{key:0,name:a.meta.icon},null,8,["name"])):f("v-if",!0)])),_:2},1024),a.meta.title?(m(),r("span",z,j(a.meta.title),1)):f("v-if",!0)],10,w)):f("v-if",!0)],64)))),256))])]),v(y)])])):f("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-339849a1"]]);export{H as default};

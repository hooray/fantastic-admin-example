
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,d as e,x as s,z as n,E as i,e as t,w as d,T as l,P as c,b as m,i as o,f as r,B as f,h as u,m as v,M as h,Q as p,n as k,L as b,R as j}from"./index.6dffb2c9.js";import x from"./index.9de3ab21.js";import y from"./index.495097eb.js";import"./logo.96f1da49.js";const M={key:0},_={class:"header-container"},g={class:"main"},w={class:"nav"},C=["onClick"],z={key:0},B=e({name:"Header"});var E=a(Object.assign(B,{setup(a){const e=s(),B=n(),E=c("switchMenu");return(a,s)=>{const n=j,c=i;return m(),t(l,{name:"header"},{default:d((()=>["pc"===o(e).mode&&"head"===o(e).menu.menuMode?(m(),r("header",M,[f("div",_,[f("div",g,[u(x),v(" 顶部模式 "),f("div",w,[(m(!0),r(h,null,p(o(B).allMenus,((a,e)=>(m(),r(h,null,[a.children&&0!==a.children.length?(m(),r("div",{key:e,class:k(["item",{active:e==o(B).actived}]),onClick:a=>o(E)(e)},[u(c,null,{default:d((()=>[a.meta.icon?(m(),t(n,{key:0,name:a.meta.icon},null,8,["name"])):v("v-if",!0)])),_:2},1024),a.meta.title?(m(),r("span",z,b(a.meta.title),1)):v("v-if",!0)],10,C)):v("v-if",!0)],64)))),256))])]),u(y)])])):v("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-339849a1"]]);export{E as default};

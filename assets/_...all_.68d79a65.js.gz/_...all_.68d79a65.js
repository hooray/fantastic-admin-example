
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,r as n,bk as s,o as e,aw as t,f as c,h as l,C as o,w as u,bl as r,O as v,P as d,G as i,b as f,$ as p,M as w,S as m}from"./index.7e6c6c91.js";const _=a=>(v("data-v-439c912c"),a=a(),d(),a),I={class:"notfound"},b={class:"content"},h=_((()=>o("h1",null,"404",-1))),y=_((()=>o("div",{class:"desc"},"抱歉，你访问的页面不存在",-1))),k={__name:"[...all]",setup(a){const r=i(),v=n({inter:null,countdown:5});function d(){r.push("/")}return s((()=>{clearInterval(v.value.inter)})),e((()=>{v.value.inter=setInterval((()=>{v.value.countdown--,0==v.value.countdown&&(clearInterval(v.value.inter),d())}),1e3)})),(a,n)=>{const s=m,e=t;return f(),c("div",I,[l(s,{name:"404",class:"icon"}),o("div",b,[h,y,l(e,{type:"primary",onClick:d},{default:u((()=>[p(w(v.value.countdown)+" 秒后，返回首页",1)])),_:1})])])}}};"function"==typeof r&&r(k);var x=a(k,[["__scopeId","data-v-439c912c"]]);export{x as default};

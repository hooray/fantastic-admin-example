
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as a}from"./logo.96f1da49.js";import{v as s,d as e,x as o,r as t,c as l,e as n,w as r,i,n as d,H as c,b as u,f,m as b,L as p}from"./index.d2f116bb.js";const m=["src"],v={key:1},g=e({name:"Logo"});var h=s(Object.assign(g,{props:{showLogo:{type:Boolean,default:!0},showTitle:{type:Boolean,default:!0}},setup(s){const e=o(),g=t("Fantastic-admin 基础版"),h=t(a),w=l((()=>{let a={};return e.dashboard.enable&&(a.name="dashboard"),a}));return(a,o)=>{const t=c("router-link");return u(),n(t,{to:i(w),class:d(["title",{"is-link":i(e).dashboard.enable}]),title:g.value},{default:r((()=>[s.showLogo?(u(),f("img",{key:0,src:h.value,class:"logo"},null,8,m)):b("v-if",!0),s.showTitle?(u(),f("span",v,p(g.value),1)):b("v-if",!0)])),_:1},8,["to","class","title"])}}}),[["__scopeId","data-v-fc6b657e"]]);export{h as default};

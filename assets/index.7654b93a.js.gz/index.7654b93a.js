
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as a,v as e,x as s,b as t,f as o,i as r,L as i,m as p,M as n,N as c,O as y,B as g}from"./index.330aad3b.js";const h=a=>(c("data-v-78cda0a3"),a=a(),y(),a),b={class:"copyright"},d=h((()=>g("span",null,"Copyright",-1))),f=h((()=>g("span",{class:"icon"},"©",-1))),l={key:0},m=["href"],v={key:1},k={key:2,href:"https://beian.miit.gov.cn/",target:"_blank",rel:"noopener"},_=a({name:"Copyright"});var u=e(Object.assign(_,{setup(a){const e=s();return(a,s)=>(t(),o("footer",b,[d,f,r(e).copyright.dates?(t(),o("span",l,i(r(e).copyright.dates),1)):p("v-if",!0),r(e).copyright.company?(t(),o(n,{key:1},[r(e).copyright.website?(t(),o("a",{key:0,href:r(e).copyright.website,target:"_blank",rel:"noopener"},i(r(e).copyright.company),9,m)):(t(),o("span",v,i(r(e).copyright.company),1))],64)):p("v-if",!0),r(e).copyright.beian?(t(),o("a",k,i(r(e).copyright.beian),1)):p("v-if",!0)]))}}),[["__scopeId","data-v-78cda0a3"]]);export{u as _};

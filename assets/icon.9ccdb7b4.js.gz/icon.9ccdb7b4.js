
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as e,E as a,az as t,f as s,h as l,w as n,bs as d,bt as o,b as r,$ as u,bw as c,S as f}from"./index.84c9bfd8.js";import p from"./alert.62ee8977.js";import"./el-alert.0cce966b.js";import"./el-link.9df77598.js";const i=u(" 搜索 "),m={__name:"icon",setup:e=>(e,d)=>{const u=c,m=f,_=a,b=t,j=o;return r(),s("div",null,[l(p),l(u,{title:"图标"}),l(j,{class:"demo"},{default:n((()=>[l(_,null,{default:n((()=>[l(m,{name:"ep:edit"})])),_:1}),l(_,null,{default:n((()=>[l(m,{name:"ep:share"})])),_:1}),l(_,null,{default:n((()=>[l(m,{name:"ep:delete"})])),_:1}),l(b,{type:"primary"},{icon:n((()=>[l(_,null,{default:n((()=>[l(m,{name:"ep:search"})])),_:1})])),default:n((()=>[i])),_:1})])),_:1})])}};"function"==typeof d&&d(m);const _=e(m,[["__scopeId","data-v-5c7b21ce"]]);export{_ as default};

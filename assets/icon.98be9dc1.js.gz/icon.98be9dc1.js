
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,E as e,aw as l,f as t,h as s,w as f,bl as n,bL as r,b as d,$ as o,bO as u,R as p}from"./index.b8cb1fc0.js";import c from"./alert.f6b8ef05.js";import"./el-alert.a925cc97.js";import"./el-link.84f0f0f5.js";const i=o(" 搜索 "),m={__name:"icon",setup:a=>(a,n)=>{const o=u,m=p,_=e,b=l,j=r;return d(),t("div",null,[s(c),s(o,{title:"图标"}),s(j,{class:"demo"},{default:f((()=>[s(_,null,{default:f((()=>[s(m,{name:"ep:edit"})])),_:1}),s(_,null,{default:f((()=>[s(m,{name:"ep:share"})])),_:1}),s(_,null,{default:f((()=>[s(m,{name:"ep:delete"})])),_:1}),s(b,{type:"primary"},{icon:f((()=>[s(_,null,{default:f((()=>[s(m,{name:"ep:search"})])),_:1})])),default:f((()=>[i])),_:1})])),_:1})])}};"function"==typeof n&&n(m);var _=a(m,[["__scopeId","data-v-5dc6bf25"]]);export{_ as default};

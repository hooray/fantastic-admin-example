
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,d as e,x as s,z as i,E as n,e as t,w as l,T as d,Q as o,b as m,i as c,f as r,h as u,m as v,C as f,N as b,R as p,n as h,M,S as g}from"./index.7e6c6c91.js";import k from"./index.b0d67396.js";import"./logo.96f1da49.js";const j={key:0,class:"main-sidebar-container"},x={class:"nav"},_=["title","onClick"],w=e({name:"MainSidebar"});var y=a(Object.assign(w,{setup(a){const e=s(),w=i(),y=o("switchMenu");return(a,s)=>{const i=g,o=n;return m(),t(d,{name:"main-sidebar"},{default:l((()=>["side"===c(e).menu.menuMode||"mobile"===c(e).mode&&"single"!==c(e).menu.menuMode?(m(),r("div",j,[u(k,{"show-title":!1,class:"sidebar-logo"}),v(" 侧边栏模式（含主导航） "),f("div",x,[(m(!0),r(b,null,p(c(w).allMenus,((a,e)=>(m(),r(b,null,[a.children&&0!==a.children.length?(m(),r("div",{key:e,class:h({item:!0,active:e===c(w).actived}),title:a.meta.title,onClick:a=>c(y)(e)},[u(o,null,{default:l((()=>[a.meta.icon?(m(),t(i,{key:0,name:a.meta.icon},null,8,["name"])):v("v-if",!0)])),_:2},1024),f("span",null,M(a.meta.title),1)],10,_)):v("v-if",!0)],64)))),256))])])):v("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-66f03716"]]);export{y as default};


/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as a,v as e,y as s,b as t,f as o,i as c,G as i,m as r,H as p,I as n,J as y,D as g}from"./index.cc47405f.js";const h=a=>(n("data-v-802cc2bf"),a=a(),y(),a),f={class:"copyright"},b=h((()=>g("span",null,"Copyright",-1))),l=h((()=>g("span",{class:"icon"},"©",-1))),m={key:0},d=["href"],k={key:1},v={key:2,href:"https://beian.miit.gov.cn/",target:"_blank",rel:"noopener"},_=a({name:"Copyright"}),u=e(Object.assign(_,{setup(a){const e=s();return(a,s)=>(t(),o("footer",f,[b,l,c(e).copyright.dates?(t(),o("span",m,i(c(e).copyright.dates),1)):r("v-if",!0),c(e).copyright.company?(t(),o(p,{key:1},[c(e).copyright.website?(t(),o("a",{key:0,href:c(e).copyright.website,target:"_blank",rel:"noopener"},i(c(e).copyright.company),9,d)):(t(),o("span",k,i(c(e).copyright.company),1))],64)):r("v-if",!0),c(e).copyright.beian?(t(),o("a",v,i(c(e).copyright.beian),1)):r("v-if",!0)]))}}),[["__scopeId","data-v-802cc2bf"]]);export{u as _};

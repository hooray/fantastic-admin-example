
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as e,d as a,y as s,M as i,b as n,e as t,w as d,i as o,f as l,D as m,h as r,m as c,H as f,Q as u,T as v,n as p,G as h,U as j,E as k}from"./index.8b097f1d.js";import x from"./index.77f9e74e.js";import{T as b}from"./index.aaa3f344.js";import{u as y}from"./index.505a345f.js";import"./logo.d9b7b1d5.js";import"./index.49187765.js";import"./eventBus.193de119.js";const _={key:0},g={class:"header-container"},M={class:"main"},T={class:"nav"},w=["onClick"],C={key:0},H=a({name:"Header"}),B=e(Object.assign(H,{setup(e){const a=s(),H=i();return(e,s)=>{const i=j,B=k;return n(),t(v,{name:"header"},{default:d((()=>["pc"===o(a).mode&&"head"===o(a).menu.menuMode?(n(),l("header",_,[m("div",g,[m("div",M,[r(x),c(" 顶部模式 "),m("div",T,[(n(!0),l(f,null,u(o(H).allMenus,((e,a)=>(n(),l(f,null,[e.children&&0!==e.children.length?(n(),l("div",{key:a,class:p(["item",{active:a==o(H).actived}]),onClick:e=>o(y)().switchTo(a)},[r(B,null,{default:d((()=>[e.meta.icon?(n(),t(i,{key:0,name:e.meta.icon},null,8,["name"])):c("v-if",!0)])),_:2},1024),e.meta.title?(n(),l("span",C,h(e.meta.title),1)):c("v-if",!0)],10,w)):c("v-if",!0)],64)))),256))])]),r(b)])])):c("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-e3de8320"]]);export{B as default};

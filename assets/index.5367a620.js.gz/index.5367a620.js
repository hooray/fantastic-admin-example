
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,d as e,z as s,B as n,Q as i,b as t,e as d,w as l,i as c,f as m,H as o,h as r,m as u,N as f,R as v,T as p,n as h,M as b,S as j,E as k}from"./index.84c9bfd8.js";import x from"./index.36d6e1db.js";import y from"./index.c0eba6db.js";import"./logo.d9b7b1d5.js";import"./index.99fc6860.js";const M={key:0},_={class:"header-container"},g={class:"main"},w={class:"nav"},C=["onClick"],H={key:0},z=e({name:"Header"}),B=a(Object.assign(z,{setup(a){const e=s(),z=n(),B=i("switchMenu");return(a,s)=>{const n=j,i=k;return t(),d(p,{name:"header"},{default:l((()=>["pc"===c(e).mode&&"head"===c(e).menu.menuMode?(t(),m("header",M,[o("div",_,[o("div",g,[r(x),u(" 顶部模式 "),o("div",w,[(t(!0),m(f,null,v(c(z).allMenus,((a,e)=>(t(),m(f,null,[a.children&&0!==a.children.length?(t(),m("div",{key:e,class:h(["item",{active:e==c(z).actived}]),onClick:a=>c(B)(e)},[r(i,null,{default:l((()=>[a.meta.icon?(t(),d(n,{key:0,name:a.meta.icon},null,8,["name"])):u("v-if",!0)])),_:2},1024),a.meta.title?(t(),m("span",H,b(a.meta.title),1)):u("v-if",!0)],10,C)):u("v-if",!0)],64)))),256))])]),r(y)])])):u("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-31571072"]]);export{B as default};

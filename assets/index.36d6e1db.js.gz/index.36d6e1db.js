
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as a}from"./logo.d9b7b1d5.js";import{v as s,d as e,z as o,r as t,c as l,G as n,b as r,e as d,w as i,f as c,m as u,M as b,i as f,n as p}from"./index.84c9bfd8.js";const m=["src"],g={key:1},h=e({name:"Logo"}),v=s(Object.assign(h,{props:{showLogo:{type:Boolean,default:!0},showTitle:{type:Boolean,default:!0}},setup(s){const e=o(),h=t("Fantastic-admin 基础版"),v=t(a),w=l((()=>{let a={};return e.dashboard.enable&&(a.name="dashboard"),a}));return(a,o)=>{const t=n("router-link");return r(),d(t,{to:f(w),class:p(["title",{"is-link":f(e).dashboard.enable}]),title:h.value},{default:i((()=>[s.showLogo?(r(),c("img",{key:0,src:v.value,class:"logo"},null,8,m)):u("v-if",!0),s.showTitle?(r(),c("span",g,b(h.value),1)):u("v-if",!0)])),_:1},8,["to","class","title"])}}}),[["__scopeId","data-v-2b7163c4"]]);export{v as default};

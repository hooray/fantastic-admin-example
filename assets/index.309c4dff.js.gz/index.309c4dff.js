
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as e,d as a,y as s,M as i,b as n,e as t,w as l,i as o,f as d,h as m,m as c,D as r,H as u,Q as f,T as v,n as b,G as p,U as h,E as g}from"./index.2c25f648.js";import j from"./index.caf63ee8.js";import{u as k}from"./index.29911242.js";import"./logo.d9b7b1d5.js";const M={key:0,class:"main-sidebar-container"},x={class:"nav"},y=["title","onClick"],_=a({name:"MainSidebar"}),w=e(Object.assign(_,{setup(e){const a=s(),_=i();return(e,s)=>{const i=h,w=g;return n(),t(v,{name:"main-sidebar"},{default:l((()=>["side"===o(a).menu.menuMode||"mobile"===o(a).mode&&"single"!==o(a).menu.menuMode?(n(),d("div",M,[m(j,{"show-title":!1,class:"sidebar-logo"}),c(" 侧边栏模式（含主导航） "),r("div",x,[(n(!0),d(u,null,f(o(_).allMenus,((e,a)=>(n(),d(u,null,[e.children&&0!==e.children.length?(n(),d("div",{key:a,class:b({item:!0,active:a===o(_).actived}),title:e.meta.title,onClick:e=>o(k)().switchTo(a)},[m(w,null,{default:l((()=>[e.meta.icon?(n(),t(i,{key:0,name:e.meta.icon},null,8,["name"])):c("v-if",!0)])),_:2},1024),r("span",null,p(e.meta.title),1)],10,y)):c("v-if",!0)],64)))),256))])])):c("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-ebc95e63"]]);export{w as default};

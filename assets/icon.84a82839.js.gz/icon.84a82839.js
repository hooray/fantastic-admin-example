
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,E as e,aw as l,f as t,h as s,w as n,bl as d,bL as r,b as o,$ as u,bO as p,R as f}from"./index.4baba6e2.js";import i from"./alert.78379ce7.js";import"./el-alert.3766ec37.js";import"./el-link.d9d8863a.js";const m=u(" 搜索 "),c={__name:"icon",setup:a=>(a,d)=>{const u=p,c=f,_=e,b=l,j=r;return o(),t("div",null,[s(i),s(u,{title:"图标"}),s(j,{class:"demo"},{default:n((()=>[s(_,null,{default:n((()=>[s(c,{name:"ep:edit"})])),_:1}),s(_,null,{default:n((()=>[s(c,{name:"ep:share"})])),_:1}),s(_,null,{default:n((()=>[s(c,{name:"ep:delete"})])),_:1}),s(b,{type:"primary"},{icon:n((()=>[s(_,null,{default:n((()=>[s(c,{name:"ep:search"})])),_:1})])),default:n((()=>[m])),_:1})])),_:1})])}};"function"==typeof d&&d(c);var _=a(c,[["__scopeId","data-v-5dc6bf25"]]);export{_ as default};

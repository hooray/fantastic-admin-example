
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as e,E as t,f as a,h as l,w as d,bu as s,bv as u,b as f,R as i,by as n,U as _}from"./index.edceb537.js";import{E as r}from"./el-link.7532a844.js";import o from"./alert.6c5246b2.js";import"./el-alert.9066d762.js";const p=i("默认链接"),c=i("主要链接"),m=i("成功链接"),y=i("警告链接"),b=i("危险链接"),g=i("信息链接"),v=i("默认链接"),h=i("主要链接"),j=i("成功链接"),w=i("警告链接"),k=i("危险链接"),x=i("信息链接"),E=i("无下划线"),I=i("有下划线"),R=i(" 编辑 "),U=i(" 查看 "),q={__name:"link",setup:e=>(e,s)=>{const i=n,q=r,z=u,A=_,B=t;return f(),a("div",null,[l(o),l(i,{title:"文字链接"}),l(z,{title:"基础用法",class:"demo"},{default:d((()=>[l(q,{href:"https://element.eleme.io",target:"_blank"},{default:d((()=>[p])),_:1}),l(q,{type:"primary"},{default:d((()=>[c])),_:1}),l(q,{type:"success"},{default:d((()=>[m])),_:1}),l(q,{type:"warning"},{default:d((()=>[y])),_:1}),l(q,{type:"danger"},{default:d((()=>[b])),_:1}),l(q,{type:"info"},{default:d((()=>[g])),_:1})])),_:1}),l(z,{title:"禁用状态",class:"demo"},{default:d((()=>[l(q,{disabled:""},{default:d((()=>[v])),_:1}),l(q,{type:"primary",disabled:""},{default:d((()=>[h])),_:1}),l(q,{type:"success",disabled:""},{default:d((()=>[j])),_:1}),l(q,{type:"warning",disabled:""},{default:d((()=>[w])),_:1}),l(q,{type:"danger",disabled:""},{default:d((()=>[k])),_:1}),l(q,{type:"info",disabled:""},{default:d((()=>[x])),_:1})])),_:1}),l(z,{title:"下划线",class:"demo"},{default:d((()=>[l(q,{underline:!1},{default:d((()=>[E])),_:1}),l(q,null,{default:d((()=>[I])),_:1})])),_:1}),l(z,{title:"图标",class:"demo"},{default:d((()=>[l(q,null,{default:d((()=>[l(B,{class:"el-icon--left"},{default:d((()=>[l(A,{name:"ep:edit"})])),_:1}),R])),_:1}),l(q,null,{default:d((()=>[U,l(B,{class:"el-icon--right"},{default:d((()=>[l(A,{name:"ep:view"})])),_:1})])),_:1})])),_:1})])}};"function"==typeof s&&s(q);const z=e(q,[["__scopeId","data-v-567744ed"]]);export{z as default};

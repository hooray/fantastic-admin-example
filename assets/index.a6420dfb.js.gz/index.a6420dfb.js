
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as t,d as a,r as s,o as e,E as i,f as n,C as o,h as l,w as c,n as r,O as d,P as p,$ as u,b as m,S as f}from"./index.9cfebd09.js";import{E as b}from"./el-notification.5161bbeb.js";const h=t=>(d("data-v-73c2bfc8"),t=t(),p(),t),g=h((()=>o("span",{class:"title"},[u("购买"),o("br"),u("专业版")],-1))),v=h((()=>o("span",{class:"title"},[u("下载"),o("br"),u("基础版")],-1))),y=h((()=>o("span",{class:"title"},[u("开发"),o("br"),u("文档")],-1))),x=h((()=>o("span",{class:"title"},[u("技术"),o("br"),u("支持")],-1))),_=a({name:"BuyIt"});var k=t(Object.assign(_,{setup(t){const a=s(!0);function d(t){window.open(t,"top")}return setTimeout((()=>{a.value=!1}),5e3),e((()=>{b({type:"success",title:"温馨提示",dangerouslyUseHTMLString:!0,message:'\n            <p>当前访问的是<b>基础版</b> (Vue3)</p>\n            <p>你可以点<a href="https://hooray.gitee.io/fantastic-admin-pro-example/" target="_blank"><b>这里</b></a>访问专业版 (Vue3)</p>\n        ',position:"bottom-right",duration:5e3})})),(t,s)=>{const e=f,p=i;return m(),n("div",{class:r(["buy-it",{actived:a.value}])},[o("div",{class:"item",onClick:s[0]||(s[0]=t=>d("https://hooray.gitee.io/fantastic-admin/buy.html"))},[l(p,null,{default:c((()=>[l(e,{name:"fixed-right-buy"})])),_:1}),g]),o("div",{class:"item",onClick:s[1]||(s[1]=t=>d("https://gitee.com/hooray/fantastic-admin/"))},[l(p,null,{default:c((()=>[l(e,{name:"fixed-right-code"})])),_:1}),v]),o("div",{class:"item",onClick:s[2]||(s[2]=t=>d("https://hooray.gitee.io/fantastic-admin/"))},[l(p,null,{default:c((()=>[l(e,{name:"fixed-right-doc"})])),_:1}),y]),o("div",{class:"item",onClick:s[3]||(s[3]=t=>d("https://hooray.gitee.io/fantastic-admin/support.html"))},[l(p,null,{default:c((()=>[l(e,{name:"fixed-right-chat"})])),_:1}),x])],2)}}}),[["__scopeId","data-v-73c2bfc8"]]);export{k as default};

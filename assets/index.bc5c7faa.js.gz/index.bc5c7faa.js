
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,d as e,y as s,M as i,b as n,e as t,w as d,i as o,f as l,D as m,h as c,m as r,H as f,Q as u,T as v,n as p,G as h,U as j,E as k}from"./index.2c25f648.js";import x from"./index.caf63ee8.js";import{T as y}from"./index.992a94d0.js";import{u as b}from"./index.29911242.js";import"./logo.d9b7b1d5.js";import"./index.f5a2aa6c.js";import"./eventBus.193de119.js";const _={key:0},g={class:"header-container"},M={class:"main"},T={class:"nav"},w=["onClick"],C={key:0},H=e({name:"Header"}),B=a(Object.assign(H,{setup(a){const e=s(),H=i();return(a,s)=>{const i=j,B=k;return n(),t(v,{name:"header"},{default:d((()=>["pc"===o(e).mode&&"head"===o(e).menu.menuMode?(n(),l("header",_,[m("div",g,[m("div",M,[c(x),r(" 顶部模式 "),m("div",T,[(n(!0),l(f,null,u(o(H).allMenus,((a,e)=>(n(),l(f,null,[a.children&&0!==a.children.length?(n(),l("div",{key:e,class:p(["item",{active:e==o(H).actived}]),onClick:a=>o(b)().switchTo(e)},[c(B,null,{default:d((()=>[a.meta.icon?(n(),t(i,{key:0,name:a.meta.icon},null,8,["name"])):r("v-if",!0)])),_:2},1024),a.meta.title?(n(),l("span",C,h(a.meta.title),1)):r("v-if",!0)],10,w)):r("v-if",!0)],64)))),256))])]),c(y)])])):r("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-e3de8320"]]);export{B as default};


/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as e,E as a,az as t,f as s,h as l,w as n,bu as d,bv as o,b as u,R as f,by as r,U as p}from"./index.cc47405f.js";import c from"./alert.9797144d.js";import"./el-alert.ddb5f59f.js";import"./el-link.b241828a.js";const i=f(" 搜索 "),m={__name:"icon",setup:e=>(e,d)=>{const f=r,m=p,_=a,b=t,j=o;return u(),s("div",null,[l(c),l(f,{title:"图标"}),l(j,{class:"demo"},{default:n((()=>[l(_,null,{default:n((()=>[l(m,{name:"ep:edit"})])),_:1}),l(_,null,{default:n((()=>[l(m,{name:"ep:share"})])),_:1}),l(_,null,{default:n((()=>[l(m,{name:"ep:delete"})])),_:1}),l(b,{type:"primary"},{icon:n((()=>[l(_,null,{default:n((()=>[l(m,{name:"ep:search"})])),_:1})])),default:n((()=>[i])),_:1})])),_:1})])}};"function"==typeof d&&d(m);const _=e(m,[["__scopeId","data-v-5c7b21ce"]]);export{_ as default};

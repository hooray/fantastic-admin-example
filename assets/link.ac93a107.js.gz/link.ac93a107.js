
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as e,E as t,f as a,h as l,w as d,bs as s,bt as f,b as i,$ as u,bw as n,S as _}from"./index.84c9bfd8.js";import{E as r}from"./el-link.9df77598.js";import o from"./alert.62ee8977.js";import"./el-alert.0cce966b.js";const p=u("默认链接"),c=u("主要链接"),m=u("成功链接"),b=u("警告链接"),y=u("危险链接"),g=u("信息链接"),w=u("默认链接"),h=u("主要链接"),j=u("成功链接"),v=u("警告链接"),k=u("危险链接"),x=u("信息链接"),E=u("无下划线"),I=u("有下划线"),S=u(" 编辑 "),$=u(" 查看 "),q={__name:"link",setup:e=>(e,s)=>{const u=n,q=r,z=f,A=_,B=t;return i(),a("div",null,[l(o),l(u,{title:"文字链接"}),l(z,{title:"基础用法",class:"demo"},{default:d((()=>[l(q,{href:"https://element.eleme.io",target:"_blank"},{default:d((()=>[p])),_:1}),l(q,{type:"primary"},{default:d((()=>[c])),_:1}),l(q,{type:"success"},{default:d((()=>[m])),_:1}),l(q,{type:"warning"},{default:d((()=>[b])),_:1}),l(q,{type:"danger"},{default:d((()=>[y])),_:1}),l(q,{type:"info"},{default:d((()=>[g])),_:1})])),_:1}),l(z,{title:"禁用状态",class:"demo"},{default:d((()=>[l(q,{disabled:""},{default:d((()=>[w])),_:1}),l(q,{type:"primary",disabled:""},{default:d((()=>[h])),_:1}),l(q,{type:"success",disabled:""},{default:d((()=>[j])),_:1}),l(q,{type:"warning",disabled:""},{default:d((()=>[v])),_:1}),l(q,{type:"danger",disabled:""},{default:d((()=>[k])),_:1}),l(q,{type:"info",disabled:""},{default:d((()=>[x])),_:1})])),_:1}),l(z,{title:"下划线",class:"demo"},{default:d((()=>[l(q,{underline:!1},{default:d((()=>[E])),_:1}),l(q,null,{default:d((()=>[I])),_:1})])),_:1}),l(z,{title:"图标",class:"demo"},{default:d((()=>[l(q,null,{default:d((()=>[l(B,{class:"el-icon--left"},{default:d((()=>[l(A,{name:"ep:edit"})])),_:1}),S])),_:1}),l(q,null,{default:d((()=>[$,l(B,{class:"el-icon--right"},{default:d((()=>[l(A,{name:"ep:view"})])),_:1})])),_:1})])),_:1})])}};"function"==typeof s&&s(q);const z=e(q,[["__scopeId","data-v-567744ed"]]);export{z as default};
